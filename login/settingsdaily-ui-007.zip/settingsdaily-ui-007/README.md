# Settings - Daily UI #007

A Pen created on CodePen.io. Original URL: [https://codepen.io/tizam/pen/YaRKYb](https://codepen.io/tizam/pen/YaRKYb).

not a pixel perfect work, but i learned a lot from this awsome settings design from Roxane Ben Sedrine 
https://dribbble.com/Chupp_